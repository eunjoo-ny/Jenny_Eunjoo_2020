#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main(void) {
	int res;
	char ch;
	while(1){
	scanf("%c", &ch);
	if (res == -1) 
		break;

		printf("%d", ch);
	}
	return 0;
}
